 function rp = vecrot(n, theta, r)
 
 rp = rotmat(n,theta)*r;
 
 end
 